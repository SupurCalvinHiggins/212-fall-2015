#pragma once
#include <vector>

bool three_sum(const std::vector<int>& arr, int target);