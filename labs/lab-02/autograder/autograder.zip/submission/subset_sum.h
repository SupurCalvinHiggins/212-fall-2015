#pragma once
#include <vector>

bool subset_sum(const std::vector<int> &arr, int target);
