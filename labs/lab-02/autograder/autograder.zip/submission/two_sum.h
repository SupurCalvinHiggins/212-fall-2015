#pragma once
#include <vector>

bool two_sum(const std::vector<int> &arr, int target);