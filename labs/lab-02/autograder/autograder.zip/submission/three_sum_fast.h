#pragma once
#include <vector>

bool three_sum_fast(const std::vector<int>& arr, int target);