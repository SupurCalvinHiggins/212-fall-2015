#pragma once
#include <string>

bool is_valid_rna_fold(const std::string &rna, const std::string &fold);
