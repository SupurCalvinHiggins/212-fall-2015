#pragma once
#include <string>

int eval(const std::string &expr);
